document.addEventListener('DOMContentLoaded', function() {
    // Variáveis globais
    let cart = [];
    let users = [];
    
    // Elementos do DOM
    const cartOverlay = document.querySelector('.cart-overlay');
    const cartContent = document.querySelector('.cart-content');
    const cartCount = document.querySelector('.cart-count');
    const totalPrice = document.querySelector('.total-price');
    const closeCartBtn = document.querySelector('.close-cart');
    const cartIcon = document.querySelector('.cart-icon');
    const addToCartBtns = document.querySelectorAll('.add-to-cart');
    const checkoutBtn = document.querySelector('.checkout-btn');
    
    // Elementos do modal
    const loginModal = document.getElementById('loginModal');
    const registerModal = document.getElementById('registerModal');
    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');
    const closeModalBtns = document.querySelectorAll('.close-modal');
    const showRegister = document.getElementById('showRegister');
    const showLogin = document.getElementById('showLogin');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    // Produtos disponíveis
    const products = [
        { id: 1, name: 'Água Mineral 500ml', price: 2.50, image: 'assets/agua1.jpg' },
        { id: 2, name: 'Água com Gás 1L', price: 4.90, image: 'assets/agua2.jpg' },
        { id: 3, name: 'Água Mineral 5L', price: 7.00, image: 'assets/agua3.jpg' }
    ];
    
    // Função para abrir o carrinho
    function openCart() {
        cartOverlay.style.display = 'flex';
        renderCartItems();
    }
    
    // Função para fechar o carrinho
    function closeCart() {
        cartOverlay.style.display = 'none';
    }
    
    // Função para renderizar os itens do carrinho
    function renderCartItems() {
        if (cart.length === 0) {
            cartContent.innerHTML = '<p class="empty-cart">Seu carrinho está vazio</p>';
            totalPrice.textContent = 'R$ 0,00';
            return;
        }
        
        cartContent.innerHTML = '';
        
        cart.forEach(item => {
            const product = products.find(p => p.id === item.id);
            const cartItem = document.createElement('div');
            cartItem.className = 'cart-item';
            cartItem.innerHTML = `
                <img src="${product.image}" alt="${product.name}">
                <div class="cart-item-info">
                    <h4 class="cart-item-title">${product.name}</h4>
                    <p class="cart-item-price">R$ ${product.price.toFixed(2)}</p>
                    <p>Quantidade: ${item.quantity}</p>
                    <button class="cart-item-remove" data-id="${item.id}">Remover</button>
                </div>
            `;
            cartContent.appendChild(cartItem);
        });
        
        // Atualizar total
        updateCartTotal();
        
        // Adicionar eventos aos botões de remover
        document.querySelectorAll('.cart-item-remove').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = parseInt(this.getAttribute('data-id'));
                removeFromCart(id);
            });
        });
    }
    
    // Função para atualizar o total do carrinho
    function updateCartTotal() {
        const total = cart.reduce((sum, item) => {
            const product = products.find(p => p.id === item.id);
            return sum + (product.price * item.quantity);
        }, 0);
        
        totalPrice.textContent = `R$ ${total.toFixed(2)}`;
        cartCount.textContent = cart.reduce((count, item) => count + item.quantity, 0);
    }
    
    // Função para adicionar item ao carrinho
    function addToCart(id) {
        const existingItem = cart.find(item => item.id === id);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ id, quantity: 1 });
        }
        
        updateCartTotal();
        renderCartItems();
        
        // Feedback visual
        const btn = document.querySelector(`.add-to-cart[data-id="${id}"]`);
        btn.textContent = 'Adicionado!';
        setTimeout(() => {
            btn.textContent = 'Adicionar ao Carrinho';
        }, 1000);
    }
    
    // Função para remover item do carrinho
    function removeFromCart(id) {
        cart = cart.filter(item => item.id !== id);
        renderCartItems();
    }
    
    // Função para abrir modal
    function openModal(modal) {
        modal.style.display = 'flex';
    }
    
    // Função para fechar modal
    function closeModal(modal) {
        modal.style.display = 'none';
    }
    
    // Função para alternar entre login e cadastro
    function toggleForms() {
        loginModal.style.display = 'none';
        registerModal.style.display = 'flex';
    }
    
    // Event Listeners
    cartIcon.addEventListener('click', openCart);
    closeCartBtn.addEventListener('click', closeCart);
    
    addToCartBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const id = parseInt(this.getAttribute('data-id'));
            addToCart(id);
        });
    });
    
    checkoutBtn.addEventListener('click', function() {
        alert('Compra finalizada com sucesso!');
        cart = [];
        renderCartItems();
        closeCart();
    });
    
    // Modal events
    loginBtn.addEventListener('click', () => openModal(loginModal));
    registerBtn.addEventListener('click', () => openModal(registerModal));
    
    closeModalBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const modal = this.closest('.modal');
            closeModal(modal);
        });
    });
    
    showRegister.addEventListener('click', function(e) {
        e.preventDefault();
        toggleForms();
    });
    
    showLogin.addEventListener('click', function(e) {
        e.preventDefault();
        loginModal.style.display = 'flex';
        registerModal.style.display = 'none';
    });
    
    // Fechar modal ao clicar fora
    window.addEventListener('click', function(e) {
        if (e.target === loginModal) {
            closeModal(loginModal);
        }
        if (e.target === registerModal) {
            closeModal(registerModal);
        }
        if (e.target === cartOverlay) {
            closeCart();
        }
    });
    
    // Formulário de login
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = this.querySelector('input[type="email"]').value;
        const password = this.querySelector('input[type="password"]').value;
        
        // Simular autenticação
        const user = users.find(u => u.email === email && u.password === password);
        
        if (user) {
            alert('Login realizado com sucesso!');
            closeModal(loginModal);
            // Aqui você poderia atualizar a UI para mostrar que o usuário está logado
        } else {
            alert('E-mail ou senha incorretos!');
        }
    });
    
    // Formulário de cadastro
    registerForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const name = this.querySelector('input[type="text"]').value;
        const email = this.querySelector('input[type="email"]').value;
        const password = this.querySelector('input[type="password"]').value;
        const confirmPassword = this.querySelectorAll('input[type="password"]')[1].value;
        
        if (password !== confirmPassword) {
            alert('As senhas não coincidem!');
            return;
        }
        
        // Verificar se o usuário já existe
        if (users.some(u => u.email === email)) {
            alert('Este e-mail já está cadastrado!');
            return;
        }
        
        // Adicionar novo usuário
        users.push({ name, email, password });
        alert('Cadastro realizado com sucesso!');
        this.reset();
        loginModal.style.display = 'flex';
        registerModal.style.display = 'none';
    });
});